package com.example.navviewapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.widget.Toast
import androidx.core.view.GravityCompat
import com.example.navviewapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var bindingClass : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bindingClass = ActivityMainBinding.inflate(layoutInflater)
        setContentView(bindingClass.root)
        bindingClass.apply {
            btnOpen.setOnClickListener{
                Toast.makeText(applicationContext,"btnOpen Click",Toast.LENGTH_SHORT).show()
                drawer.openDrawer(GravityCompat.START)
            }
        }
    }
}